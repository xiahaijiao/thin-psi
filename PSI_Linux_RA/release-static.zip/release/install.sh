# yum install -y usbutils gcc-c++.x86_64 gcc.x86_64 cmake.x86_64 gmp-devel openssl-devel boost-devel 
yum install gcc gcc-c++ make -y

