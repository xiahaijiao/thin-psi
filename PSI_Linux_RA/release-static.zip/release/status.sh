 ps -ef |grep acka
