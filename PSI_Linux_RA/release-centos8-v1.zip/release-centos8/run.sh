
starttime=`date +'%Y-%m-%d_%H_%M_%S'`
nohup ./main2.sh >> $starttime 2>&1 &
