 ps -ef | grep testPSI.jar
