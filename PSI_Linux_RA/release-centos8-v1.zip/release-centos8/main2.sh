startX=1
baseG="0279BE667EF9DCBBAC55A06295CE870B07029BFCDB2DCE28D959F2815B16F81798"
a_str="73aa7c979bb15317727fe8c587825ba6c3422c67cca28c01ac50b2ca1b7ce93b"
#a_str="779dd6e5189c2695ec5ae789d9bc9fede2b7fd80d66019a65e4a568dbec5a805"
#a_str="68450b6d617318cf99cb3172e1682b7ee924dfafad77120055ee9a91fee78e1"
len_cmp=2
random=1
echo -e "$startX\n $baseG\n $a_str\n $len_cmp\n $random"| ./main.sh

