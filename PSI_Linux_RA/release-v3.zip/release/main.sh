#make
java -jar testPSI.jar
